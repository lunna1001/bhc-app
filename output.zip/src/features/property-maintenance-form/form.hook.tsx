import React, { useState } from 'react';
import addFormItem from './form.server';

export default function () {
    const [name, setName] = useState('');
    const [email, setEmail] = useState('');
    const [country, setCountry] = useState('');
    const [city, setCity] = useState('');
    const [newItemErr, setNewItemErr] = useState('');
    const [loading, setLoading] = useState(false);
    const [showAlert, setShowAlert] = useState(false);

    const addFormItems = React.useCallback(async () => {
        if (!name)
            return setNewItemErr('Name is required');
        if (!email)
            return setNewItemErr('Email is required');
        if (!country)
            return setNewItemErr('Country is required');
        if (!city)
            return setNewItemErr('City is required')

        setLoading(true);
        setNewItemErr('');

        try {
            await addFormItem(name, email, country, city).then(() => {
                setName("");
                setEmail("");
                setCountry("")
                setCity("")
                setShowAlert(true)
                setTimeout(() => {
                    setShowAlert(false)
                }, 1500)
            })
        } catch (e: any) {
            setNewItemErr(e?.message);
        }

        setLoading(false);
    }, [name, email, country, city]);

    const disabledState = React.useMemo(() => {
        if (!name || !email || !country || !city) {
            return true
        } else {
            return false
        }
    }, [name, email, country, city])

    return {
        name, setName,
        email, setEmail,
        country, setCountry,
        city, setCity,
        newItemErr,
        addFormItems,
        loading,
        showAlert,
        disabledState
    }
}