import { loadConfig } from '@magicjs.dev/frontend';
import React from 'react';
import useListHook from './form-list.hook';
import configJson from './config.json';
import { Table } from 'antd';
import moment from 'moment';

const config = loadConfig(configJson);

export default function FormList() {
    const hook = useListHook();

    const columns: any = [
        {
            title: 'Name',
            dataIndex: 'name',
        },
        {
            title: 'Email',
            dataIndex: 'email',
        },
        {
            title: 'Country',
            dataIndex: 'country',
            responsive: ['lg'],
        },
        {
            title: 'City',
            dataIndex: 'city',
            responsive: ['lg'],
        },
        {
            title: 'Created At',
            dataIndex: 'createdAt',
            responsive: ['lg'],
            render: (createdAt) => {
                return (
                    <>
                        <span>{moment(createdAt).format('ll')}</span>
                    </>
                )
            },
        },
    ];

    return (
        <>
            <div>
                <header className="bg-white shadow fixed top-0 left-0 right-0 lg:ml-[256px] z-10 lg:pt-0 pt-[60px]">
                    <div className="px-4 py-7 sm:px-12 flex flex-row justify-between items-center">
                        <h1 className="text-2xl font-bold tracking-tight text-gray-900 truncate w-3/6">{config.getValue('label')}</h1>
                    </div>
                </header>
                <main className='pt-[86px]'>
                    <div className="px-4 py-6 sm:px-12">
                        <section className='bg-white dark:bg-dark flex justify-center p-5'>
                            <div className='container'>
                                <div className='flex flex-wrap -mx-4'>
                                    <div className='w-full '>
                                        <div className='max-w-full overflow-x-aut'>
                                            <Table
                                                size="small"
                                                rowKey={(item) => item._id}
                                                columns={columns}
                                                dataSource={hook.data}
                                            />
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </section>
                    </div>
                </main>
            </div>
        </>
    )
}