import React, { useState } from 'react';
import listItem from './form-list.server';

export default function () {
    const [data, setData] = useState<any[]>([]);

    const refresh = React.useCallback(() => {
        listItem().then(setData);
    }, []);

    React.useEffect(() => {
        refresh();
    }, []);

    return {
        data
    }
}