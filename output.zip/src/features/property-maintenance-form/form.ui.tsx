import React from 'react';
import { importUI } from '@magicjs.dev/frontend';
import { Helmet } from 'react-helmet-async';

const Header = importUI("@mern.ai/standard-header")
const Forms = importUI("@mern.ai/form")
const Footer = importUI("@mern.ai/standard-footer")

export default function Form() {
    return (
        <div>
            <Helmet>
                <title>Form</title>
            </Helmet>
            <Header />
            <Forms />
            <Footer />
        </div>
    )
}