import { createBackendFunction, data, loadConfig } from "@magicjs.dev/backend";
import configJson from './config.json';

const config = loadConfig(configJson);

export default createBackendFunction(async function () {
    const forms = data(config.getValue('mongoDbCollectionName'));
    return await forms.find().toArray();
})