import { createBackendFunction, data, loadConfig } from "@magicjs.dev/backend";
import moment from "moment";
import configJson from './config.json';

const config = loadConfig(configJson);

export default createBackendFunction(async function (name, email, country, city) {
    const forms = data(config.getValue('mongoDbCollectionName'));
    try {
        const item = await forms.insertOne({
            name,
            email,
            country,
            city,
            createdAt: moment.utc().valueOf(),
        });

        return item;
    } catch (error) {
        throw new Error(error?.message || "Internal server error");
    }
})